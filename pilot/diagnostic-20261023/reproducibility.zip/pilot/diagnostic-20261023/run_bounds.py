import json, os
from pathlib import Path
from kroc_mobo.experiments import run_exp1

root = Path(__file__).resolve().parent
repo = root.parents[1] / 'kroc-payload-mobo'
c = json.loads((repo/'results/budget80-20260927/canonical/config.json').read_text())
c['experiment']['payloads'] = [1.0]
for key, upper in zip(('kp','ki','kd'), (1600.,800.,160.)):
    c['search'][key] = [0., upper]
run_exp1(c, root/'bounds_expanded')
