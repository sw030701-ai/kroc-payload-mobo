import json, hashlib, sys
from pathlib import Path
from copy import deepcopy
import numpy as np
import pandas as pd
from kroc_mobo.config import seeds
from kroc_mobo.metrics import GAINS, OBJECTIVES, pareto, representatives, hypervolume
from kroc_mobo.experiments import evaluate_row
from kroc_mobo.simulation import simulate
from kroc_mobo.plant import inertia, gravity_coefficient
from kroc_mobo.io import save_csv, save_json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]/'kroc-payload-mobo'
PARENT=REPO/'results/budget80-20260927/canonical'
HEAVY=REPO/'results/heavy-diagnostics-20261001'
C=json.loads((PARENT/'config.json').read_text())
def read(p): return pd.read_csv(p, float_precision='round_trip')
def best(f): return f.loc[f.feasible & np.isfinite(f[OBJECTIVES]).all(axis=1)].sort_values(OBJECTIVES+GAINS).iloc[0]
def fresh(r): return list(range(400000+1000*r,400010+1000*r))
def save(name,rows): save_csv(ROOT/(name+'.csv'),rows)
def protect():
    paths=[]
    for top in ['src','configs','docs','results','reports']:
        paths.extend(p for p in (REPO/top).rglob('*') if p.is_file() and '__pycache__' not in str(p))
    paths.extend(p for p in (ROOT.parents[1]/'sources').rglob('*') if p.is_file())
    return {str(p.relative_to(ROOT.parents[1])): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}

def initial():
    save_json(ROOT/'protected_before.json',protect())
    rows=[]; raw=[]; frozen=[]
    # Freeze every budget and current-ablation controller before fresh evaluation.
    for r in range(5):
        for p in (1.,2.,3.):
            f=read(PARENT/f'exp1/repeat_{r:02d}/payload_{p:g}kg/selection.csv')
            roll=read(PARENT/f'exp1/repeat_{r:02d}/payload_{p:g}kg/selection_rollouts.csv')
            relaxed=roll.assign(ok=lambda a: (~a.numerical_failure)&(a.max_angle<=C['limits']['angle_abs_max'])&(a.max_velocity<=C['limits']['velocity_abs_max'])).groupby('controller_id').ok.all()
            for mode,g in [('canonical',f),('ignore_current',f.assign(feasible=f.controller_id.map(relaxed)))]:
                reps,status=representatives(g,tracking_max=.05)
                for _,v in reps.iterrows():
                    frozen.append(dict(v,kind='current_ablation',mode=mode,repeat=r,payload=p))
            if p>1:
                ext=read(HEAVY/f'mobo160/repeat_{r:02d}/payload_{p:g}kg/selection.csv')
                for mode,g in [('mobo80',f),('mobo160',ext)]:
                    frozen.append(dict(best(g),kind='budget',mode=mode,role='CT',repeat=r,payload=p))
    # Include original nominal CT transfer as primary cross-payload reference.
    orig=read(PARENT/'exp2/representatives_frozen.csv')
    for _,v in orig.loc[orig.role=='CT'].iterrows():
        for p in (1.,2.,3.): frozen.append(dict(v,kind='transfer',mode='original_CT',payload=p))
    save('frozen_diagnostic_candidates',frozen)
    cache={}
    for v in frozen:
        r,p=int(v['repeat']),v['payload']
        key=(r,p,*[v[g] for g in GAINS])
        if key not in cache:
            row,detail=evaluate_row(v,p,C,fresh(r),repeat=r,phase='fresh_confirmation')
            cache[key]=row
            raw.extend(detail)
        rows.append(dict(cache[key],kind=v['kind'],mode=v['mode'],role=v['role'],selection_JT=v['JT'],selection_JE=v['JE']))
    save('fresh_confirmation',rows);save('fresh_rollouts',raw)
    print('fresh confirmation complete',len(rows),len(raw),flush=True)
    hv=[]; cfg=[]
    for name,path in [('canonical',PARENT),('heavy',HEAVY)]:
        q=json.loads((path/'config.json').read_text())
        cfg.append(dict(name=name,scales=q['mobo']['objective_scales'],reference=q['mobo']['reference_point'],consistent=q['mobo']['objective_scales']==[.1,10.] and q['mobo']['reference_point']==[1.,20.]))
    for stage in ['exp1','exp2']:
        for name in (['pareto_all.csv'] if stage=='exp1' else ['transfer_all.csv','local_retested_all.csv']):
            f=read(PARENT/stage/name)
            for (r,p),g in f.groupby(['repeat','payload']):
                y=g.loc[g.feasible,OBJECTIVES].to_numpy();sc=np.array([.1,10.]);ref=np.array([1.,20.])
                a=hypervolume(y,ref)/np.prod(sc);b=hypervolume(y/sc,ref/sc)
                hv.append(dict(stage=stage,file=name,repeat=r,payload=p,raw_HV_div_scales=a,scaled_HV=b,delta=b-a,outside_reference=int(np.any(y>=ref,axis=1).sum())))
    save('hypervolume_checks',hv);save_json(ROOT/'hv_configs.json',cfg)
    physics=[]
    for p in np.arange(0,5.01,.5):
        plant=C['plant'];j=inertia(plant,p);ja=plant['N']**2*(plant['J_m']+plant['J_g'])
        physics.append(dict(payload=p,Jeq=j,Jeq_ratio_to_1kg=j/inertia(plant,1),reflected_inertia=ja,reflected_fraction=ja/j,gravity_coefficient=gravity_coefficient(plant,p),static_current_at_target=gravity_coefficient(plant,p)*np.sin(C['simulation']['theta_end'])/(plant['eta']*plant['N']*plant['K_t'])))
    save('payload_sanity',physics)

def final():
    require=ROOT/'bounds_expanded/exp1/manifest.json'
    assert json.loads(require.read_text())['status']=='completed'
    expanded=read(ROOT/'bounds_expanded/exp1/selection_all.csv')
    # Check pairing of all non-domain settings and copied numerical source.
    ec=json.loads((ROOT/'bounds_expanded/config.json').read_text())
    for section in ['plant','simulation','controller','limits','noise','mobo','selection']:
        assert ec[section]==C[section],section
    for key,value in C['experiment'].items():
        if key!='payloads': assert ec['experiment'][key]==value,key
    for p in (ROOT/'source/kroc_mobo').glob('*.py'):
        assert p.read_bytes()==(REPO/'src/kroc_mobo'/p.name).read_bytes(),p.name
    save_json(ROOT/'paired_settings_audit.json',dict(passed=True,only_changes=['search upper bounds','nominal payload subset'],optimizer_seeds=list(range(731,736))))
    bound=[];frozen=[];raw=[];rows=[];numerics=[]
    for r in range(5):
        old=read(PARENT/f'exp1/repeat_{r:02d}/payload_1kg/selection.csv')
        new=expanded.loc[expanded.repeat==r]
        for mode,f,upper in [('current',old,np.array([800,400,80])),('expanded',new,np.array([1600,800,160]))]:
            v=best(f)
            bound.append(dict(repeat=r,mode=mode,**{g:v[g] for g in GAINS+OBJECTIVES},at_upper=bool(np.any((upper-v[GAINS].to_numpy(float))<=.001*upper)),max_current=v.max_current,saturation_fraction=v.saturation_fraction,feasible=v.feasible))
            for p in (1.,2.,3.): frozen.append(dict(v,mode=mode,payload=p))
    save('bounds_selection',bound);save('bounds_frozen_before_test',frozen)
    for v in frozen:
        r,p=int(v['repeat']),v['payload']
        row,detail=evaluate_row(v,p,C,fresh(r),repeat=r,phase='fresh_bounds',mode=v['mode'])
        rows.append(row);raw.extend(detail)
        if p==1 and v['mode']=='expanded':
            co=deepcopy(C);co['simulation']['integration_substeps']=32
            a=simulate([v[g] for g in GAINS],p,C,fresh(r)[0]).metrics
            b=simulate([v[g] for g in GAINS],p,co,fresh(r)[0]).metrics
            numerics.append(dict(repeat=r,JT16=a['JT'],JT32=b['JT'],JE16=a['JE'],JE32=b['JE'],current16=a['max_current'],current32=b['max_current'],feasible16=a['feasible'],feasible32=b['feasible']))
            if r==0:
                trace=simulate([v[g] for g in GAINS],p,C,fresh(r)[0],record=True)
                save('expanded_CT_trace_r00_1kg',trace.trace)
    save('bounds_fresh_confirmation',rows);save('bounds_fresh_rollouts',raw);save('bounds_numerical_checks',numerics)
    # Explicit current-filter effect inside the newly expanded evaluated pool.
    expanded_ablation=[]
    for r in range(5):
        f=expanded.loc[expanded.repeat==r]
        eligible=f.loc[~f.numerical_failure & ~f.violation.fillna('').str.contains('angle|velocity')]
        for mode,g in [('canonical',f.loc[f.feasible]),('ignore_current',eligible)]:
            v=g.sort_values(OBJECTIVES+GAINS).iloc[0]
            expanded_ablation.append(dict(repeat=r,mode=mode,**{k:v[k] for k in GAINS+OBJECTIVES+['feasible','max_current']}))
    save('expanded_current_selection',expanded_ablation)
    allraw=pd.concat([read(ROOT/'fresh_rollouts.csv'),pd.DataFrame(raw)],ignore_index=True)
    energy=dict(new_rollouts=len(allraw),net_decomposition_max_abs=float((allraw.JE-allraw.energy_drawn+allraw.energy_returned).abs().max()),balance_residual_max_abs=float(allraw.energy_balance_residual.abs().max()),returned_max=float(allraw.energy_returned.max()),transmission_exchange_min=float(allraw.transmission_exchange.min()))
    save_json(ROOT/'energy_checks.json',energy)
    before=json.loads((ROOT/'protected_before.json').read_text());after=protect()
    save_json(ROOT/'preservation_audit.json',dict(files=len(before),unchanged=before==after,changed=[p for p,h in before.items() if after.get(p)!=h],added=[p for p in after if p not in before]))
    assert before==after
    print('FINAL COMPLETE',energy,flush=True)

if __name__=='__main__':
    (initial if sys.argv[1]=='initial' else final)()
