import json, hashlib, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from diagnose import ROOT, REPO, PARENT, C, read
from kroc_mobo.metrics import pareto

def table(f):
    def fmt(v):
        return f'{v:.6g}' if isinstance(v,(float,np.floating)) else str(v)
    return '\n'.join(['| '+' | '.join(map(str,f.columns))+' |','| '+' | '.join(['---']*len(f.columns))+' |']+['| '+' | '.join(fmt(v) for v in row)+' |' for row in f.itertuples(index=False,name=None)])

f=read(ROOT/'fresh_confirmation.csv')
b=read(ROOT/'bounds_selection.csv')
bf=read(ROOT/'bounds_fresh_confirmation.csv')
paired=b.pivot(index='repeat',columns='mode',values='JT')
gain_improvement=100*(1-paired.expanded.mean()/paired.current.mean())
budget=f.loc[f.kind=='budget'].pivot(index=['repeat','payload'],columns='mode',values='JT').reset_index()
budget['improvement_pct']=100*(1-budget.mobo160/budget.mobo80)
budget.to_csv(ROOT/'budget_fresh_paired.csv',index=False)
budget_summary=budget.groupby('payload').agg(JT80=('mobo80','mean'),JT160=('mobo160','mean'),SD80=('mobo80','std'),SD160=('mobo160','std')).reset_index()
budget_summary['improvement_pct']=100*(1-budget_summary.JT160/budget_summary.JT80)
budget_summary.to_csv(ROOT/'budget_fresh_summary.csv',index=False)
ab=f.loc[f.kind=='current_ablation']
keys=['repeat','payload','role']
a=ab.loc[ab['mode']=='canonical'].set_index(keys)
z=ab.loc[ab['mode']=='ignore_current'].set_index(keys)
ac=a[['controller_id','JT','max_current','feasible']].join(z[['controller_id','JT','max_current','feasible']],lsuffix='_canonical',rsuffix='_ignore_current')
ac['selection_changed']=ac.controller_id_canonical!=ac.controller_id_ignore_current
ac.reset_index().to_csv(ROOT/'current_selection_paired.csv',index=False)
ac_summary=ac.reset_index().groupby(['payload','role']).agg(changed=('selection_changed','sum'),canonical_pass=('feasible_canonical','sum'),ignore_current_pass=('feasible_ignore_current','sum')).reset_index()
ac_summary.to_csv(ROOT/'current_selection_summary.csv',index=False)
transfer=f.loc[f.kind=='transfer']
phys=read(ROOT/'payload_sanity.csv')
hv=read(ROOT/'hypervolume_checks.csv')
energy=json.loads((ROOT/'energy_checks.json').read_text())
numerics=read(ROOT/'bounds_numerical_checks.csv')
preserved=json.loads((ROOT/'preservation_audit.json').read_text())
fig,ax=plt.subplots(1,3,figsize=(14,4))
for r,row in paired.iterrows(): ax[0].plot([0,1],row[['current','expanded']]*1000,'o-',alpha=.7,label=f'r{r}')
ax[0].set(xticks=[0,1],xticklabels=['[800,400,80]','[1600,800,160]'],ylabel='Selection minimum JT [mrad]',title='1 kg: paired 80-evaluation bound test')
for p,g in budget.groupby('payload'):
    for i,(_,v) in enumerate(g.iterrows()): ax[1].plot([0,1],np.array([v.mobo80,v.mobo160])*1000,'o-',color=f'C{int(p)}',alpha=.6,label=f'{p:g} kg' if i==0 else None)
ax[1].legend()
ax[1].set(xticks=[0,1],xticklabels=['80','160'],ylabel='Fresh JT [mrad]',title='2/3 kg: frozen budget winners')
for name,g in bf.groupby('mode'):
    means=g.groupby('payload').JT.mean()*1000
    ax[2].plot(means.index,means,'o-',label=name)
    for p,y in means.items():
        passed=int(g.loc[g.payload==p].feasible.sum())
        ax[2].annotate(f'{passed}/5 pass',(p,y),xytext=(0,8),textcoords='offset points',ha='center',fontsize=8)
ax[2].set(xlabel='Payload [kg]',ylabel='Fresh JT [mrad]',title='Fixed CT transfer: error and feasibility',ylim=(.45,1.03))
ax[2].legend()
for a0 in ax:a0.grid(alpha=.2)
fig.tight_layout();fig.savefig(ROOT/'diagnostic_overview.png',dpi=180);fig.savefig(ROOT/'diagnostic_overview.pdf');plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(10,4))
for name,g in bf.groupby('mode'):
    # Feasibility is per 10-rollout group, not per optimizer discovery.
    v=g.groupby('payload').feasible.sum();axes[0].plot(v.index,v,'o-',label=name)
axes[0].set(xlabel='Payload [kg]',ylabel='Groups passing all 10 seeds / 5',ylim=(-.2,5.2),title='Fresh peak-current feasibility');axes[0].legend()
axes[1].plot(phys.payload,phys.Jeq_ratio_to_1kg,'o-');axes[1].set(xlabel='Payload [kg]',ylabel='Equivalent inertia / 1 kg inertia',title='Inertia ratio includes reflected motor/gear')
for a0 in axes:a0.grid(alpha=.2)
fig.tight_layout();fig.savefig(ROOT/'feasibility_and_inertia.png',dpi=180);plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(11,4))
expanded=read(ROOT/'bounds_expanded/exp1/selection_all.csv')
for r in range(5):
    for name,g,color in [('current',read(PARENT/f'exp1/repeat_{r:02d}/payload_1kg/selection.csv'),'C0'),('expanded',expanded.loc[expanded.repeat==r],'C1')]:
        g=pareto(g)
        for ax,limit in zip(axes,[.05,.002]):
            view=g.loc[g.JT<=limit].sort_values('JT')
            ax.plot(view.JT*1000,view.JE,'o-',color=color,alpha=.5,ms=3,label=name if r==0 else None)
axes[0].set(xlim=(0,50),title='1 kg practical region: individual fronts')
axes[1].set(xlim=(0,2),title='Tracking extreme zoom: individual fronts')
for ax in axes: ax.set(xlabel='Selection JT [mrad]',ylabel='Net terminal energy JE [J]');ax.grid(alpha=.2)
axes[0].legend();fig.tight_layout();fig.savefig(ROOT/'bounds_pareto.png',dpi=180);plt.close(fig)

summary=bf.groupby(['mode','payload']).agg(JT=('JT','mean'),JE=('JE','mean'),feasible_groups=('feasible','sum'),Imax=('max_current','max')).reset_index()
summary.to_csv(ROOT/'bounds_transfer_summary.csv',index=False)
oldfresh=transfer.groupby('payload').agg(JT=('JT','mean'),JE=('JE','mean'),feasible_groups=('feasible','sum')).reset_index()
raw=read(ROOT/'fresh_rollouts.csv')
ct3=raw.loc[(raw.payload==3)&(raw.kp==800)&(raw.ki==400)&(raw.kd==0)]
report=f'''# KRoC pilot diagnostic results 2026 10 23

## Main finding

Expanding nominal bounds to [1600,800,160] at unchanged 80-evaluation budget
changed the mean feasible selection minimum JT by {gain_improvement:.3f}% improvement.
Expanded winners touch an upper bound in {int(b.loc[b['mode']=='expanded'].at_upper.sum())}/5 repeats.
This is a sensitivity test of finite observed fronts, not a global optimum claim.
All original scientific files were preserved: {preserved['files']} file hashes unchanged.

## Provenance and execution

Research baseline is GitHub branch revision/heavy-payload-diagnostics-20261001,
commit 9a27fd0569f2bb9f03b21666192028a53e3298fa (remote verified). The default main
branch points to older commit 2f21d55fb8eadfbfed97a10e5a21e6b78594492b.
No remote branch or original file was changed. Output lives in this separate pilot path.
PROTOCOL.md was written before numerical execution. Source copy is under source/.
New computation: expanded 1 kg qLogNEHVI, 5 repeats x 80 candidates = 400 candidates,
1,200 training plus 2,000 selection rollouts. Initial design uses the SAME normalized
Sobol sequence and optimizer/noise seeds; physical gains scale with the wider box.
Existing baseline 80 and heavy 160 optimization were reused and audited, not rerun.
Fresh tests: {energy['new_rollouts']} rollouts saved across fresh_rollouts.csv and
bounds_fresh_rollouts.csv (duplicate controller evaluations cached within first stage).
Also five 32-substep refinement rollouts plus one recorded example trace.
Same comparison noise seeds: 400000+1000r through +9, disjoint from archived train,
selection, test and confirmation sets. Winners frozen before fresh tests.
Repeated tests reuse physical gains if roles coincide; do not count them as independent
optimization discoveries. Bounds winners are selected on selection seeds only.

## Gain bound sensitivity

{table(b)}

Fresh fixed-gain transfers, including infeasible outcomes (JT averages are not
feasible-only performance rankings):

{table(summary)}

The domain comparison keeps proposal budget and algorithm fixed. A larger domain
changes candidate coverage and current-noise amplification. More accurate tracking
may cost energy and feasibility. Neither gain boundary nor zero voltage saturation
establishes a physically optimal envelope. Do not substitute pilot CTs into the old
cross-payload table; that would mix controller selection protocols.

## Evaluation budget sensitivity

The existing 80→160 continuations passed 1,292 checks in budget_audit_verified/AUDIT.json,
including exact inherited values, source/parent hashes, raw means, seeds, budgets,
feasibility and frozen winners. A first audit invocation used the wrong working directory
and failed resolving a relative archive path; its log is retained. The successful audit
used the repository working directory and wrote all outputs into the pilot path.

Fresh-seed comparison of the frozen 80/160 winners:

{table(budget_summary)}

All repeat-specific values are in budget_fresh_paired.csv. These results test the
archived continuation and fresh predictive performance; no new 160-candidate
optimization is claimed. The archived selection improvement is 9.16% at 2 kg and
26.93% at 3 kg. Full-front HV can be dominated by low-energy/poor-tracking regions;
JT extreme and common-JT energy comparisons remain necessary.

## Current feasibility and extreme selection

Within the same 80 evaluated candidates per condition, removing ONLY the current
feasibility filter changes the representative selections as follows:

{table(ac_summary)}

Other numerical, angle and velocity constraints stay active. The table gives counts
out of five repeats, not a new unconstrained optimization. Re-evaluation always applies
the canonical 3.84 A limit so failure remains visible. The nominal CT transfer on new
seeds is:

{table(oldfresh)}

At 3 kg, original CT passes {int(ct3.feasible.sum())}/{len(ct3)} individual fresh rollouts,
but only {int(transfer.loc[transfer.payload==3].feasible.sum())}/5 groups pass all ten.
The main paper's 3/5 is its original fixed test set; retain that result, and disclose
this new 2/5-group diagnostic as seed sensitivity. All original nominal CT gains are
[800,400,0], so these five groups do not represent five distinct gain discoveries.
Current infeasibility is not voltage clipping or proof of a global performance limit.

## Hypervolume and normalization

Checked {len(hv)} payload/repeat front collections with fixed objective scales
[0.1 rad,10 J] and common reference [1 rad,20 J]. Maximum raw/scaled HV discrepancy
is {hv.delta.abs().max():.4g}; {int(hv.outside_reference.sum())} feasible points lie outside
the reference in the audited collections. Configs agree. The acquisition code transforms
minimization objectives and reference together with a minus sign and the same scales.
CB uses nominal practical-subset min/max normalization; this is deliberately separate
from common HV normalization. No payload-dependent rescaling was found.

## Payload inertia and energy sanity

{table(phys.loc[phys.payload.isin([1.,2.,3.])])}

Tripling payload from 1 to 3 kg increases total equivalent inertia by only 40.44%,
because reflected motor+gear inertia is 0.15113952 kg m². Gravity coefficient grows
2.6-fold. Thus payload effects combine gravity and inertia. Keep 1/2/3 kg for this study;
do not call them a 3:1 total-inertia range. Values at 0..5 kg are descriptive calculations,
not validation of a larger operating range or gearhead/thermal safety.
JE means signed motor-terminal net electrical energy, not battery draw. Maximum
abs(JE - drawn + returned) is {energy['net_decomposition_max_abs']:.4g} J; maximum
algebraic energy balance residual is {energy['balance_residual_max_abs']:.4g} J.
Maximum returned energy is {energy['returned_max']:.4g} J and minimum transmission
exchange is {energy['transmission_exchange_min']:.4g} J. The supplied constant-efficiency
bidirectional model has an algebraic exchange term; it is not a validated dissipative
gear loss model. Kt and Ke remain as user-supplied rounded constants.
Numerical refinement max |JT32-JT16| = {abs(numerics.JT32-numerics.JT16).max():.4g} rad,
max |JE32-JE16| = {abs(numerics.JE32-numerics.JE16).max():.4g} J.
The expanded-current selection table separately records how the current filter changes
the minimum-JT winner in the expanded pool (expanded_current_selection.csv).

## Main experiment decision

Preserve the original [800,400,80], 80-evaluation experiment and fixed CT/CB/CE.
It supports a bounded, finite-budget approximate tradeoff and transfer study.
Wider bounds and 160 evaluations belong in diagnostics and must be acknowledged;
neither current data nor this pilot establishes convergence. If the paper intends
to claim a bound-independent achievable envelope or optimal tuning, it needs a NEW
uniformly specified main study for all payloads and repeats; replacing selected
rows or nominal gains alone is not valid. Do not increase current_max to make failures
disappear: 3.84 A is an experiment convention, not an identified peak hardware rating.

## Paper text and four page priorities

Keep payload-specific fronts (five separate repeats, shared axes), a compact CT/CB/CE
cross-payload table with JT/JE and feasibility, and the original CT 3 kg 3/5 result.
Keep model equations including N=126, reflected inertia and efficiency, the signed
terminal-energy definition, 3.84 A feasibility rule, separate train/selection/test seeds,
and qLogNEHVI / 80-evaluation settings. Compress diagnostics to a short limitations
paragraph containing bound and budget sensitivity and fresh current-feasibility evidence.
Keep full per-repeat tables, HV audit, gain details and energy accounting here.
Do not remove cross-payload transfer from the four-page paper.

The user-provided Google Docs source was fetched as readable text from
https://docs.google.com/document/d/1WKhkEWoDohY0o2GnRT-0y6-XEwAElDZutjmWLGD0yn0
It is a September 21 pre-results draft, not the later six-page results draft described
in the referenced conversation. draft_readback.txt preserves the fetched text.
The originally named /mnt/data/KRoC_Payload_MOBO_Final.docx is unavailable here.
Required source corrections: direct drive → 126:1 geared model; unspecified settings
→ canonical values; qNEHVI → qLogNEHVI; full-front CE and endpoint-excluding CB →
JT<=0.05 practical subset excluding zero PID, CB over the entire subset with coincident
roles allowed. Results/abstract placeholders need actual main results. These are
method discrepancies, not page-layout judgments; no original document was edited.

## Reproduction

Use Python and package versions recorded in bounds_expanded/exp1/manifest.json.
From the project workspace, set PYTHONPATH to this directory's source, MPLCONFIGDIR
and NUMBA_CACHE_DIR to writable temporary paths, and OMP/OPENBLAS/MKL_NUM_THREADS=1.
run_bounds.py refuses an already completed output; use a new copy of this pilot folder
without generated outputs for a fresh optimization. Then run diagnose.py initial,
diagnose.py final, summarize.py. initial can run while bounds is computing; final requires
completed expanded bounds. The existing heavy report audit requires the repository
working directory and a NEW --out path outside the repository, as recorded in logs.
Parent raw data and initial protocol are not included as newly executed optimization.
SHA256SUMS.json covers delivered pilot files; protected_before.json identifies exact
original inputs; preservation_audit.json proves their unchanged content.
'''
(ROOT/'REPORT.md').write_text(report)
print(table(summary));print('Bound improvement',gain_improvement)
