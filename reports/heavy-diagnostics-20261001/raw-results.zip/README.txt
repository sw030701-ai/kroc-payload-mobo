Supplementary revision-4 diagnostics. Paths are repository-relative.
Extract into the matching repository checkout. To reproduce/verify parent hashes, also extract
the prior 80-evaluation raw-results.zip from reports/archive/canonical-final-20260927-budget80.
mobo160 inherits the first 80 observations; so40 is warm-started with nominal CT.
Both are supplementary, not replacements for the main 80-evaluation Experiment 1/2.
Effective per-condition config, inherited hashes, seeds, manifests and frozen winners are included.
source/src records the exact executed code; source/reporting records report/audit programs.
