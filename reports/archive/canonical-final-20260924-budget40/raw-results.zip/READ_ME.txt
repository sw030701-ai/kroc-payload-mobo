Full raw data for the 2026-09-24 canonical revision. Extract into a new folder.
The kroc-payload-mobo subtree contains the current source and both sensitivity and canonical runs.
Execution source snapshots are inside each run family; canonical commit ef04ab6; reporting commit 5bc2af3.
Old canonical raw data remains separately preserved in the original archive and local run directory.
Do not interpret separate optimization repeats as one pooled Pareto front.
For the archive-preservation portion of audit_revision.py, use this data in the repository with reports/archive/canonical-final-20260923 available.
