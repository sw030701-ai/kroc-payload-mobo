Raw 2026-09-27 bound/budget follow-up. Paths are relative to the repository root.
Extract into the matching repository checkout. current/expanded are paired 1 kg sensitivity arms;
canonical is the fresh selected-bound 1/2/3 kg run. All use 80 evaluations.
source/src contains the exact execution code hashed in the run manifests.
source/configs preserves pre-run configs; effective configs are each arm's config.json.
protocol.json and source/run_budget80.py specify overrides and the decision rule.
Source/reporting contains report/audit/packaging code; no Experiment 3.
